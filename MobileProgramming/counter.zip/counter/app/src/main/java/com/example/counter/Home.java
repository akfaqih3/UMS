package com.example.counter;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Home extends AppCompatActivity {

    Button btn_count,btnReset ;
    TextView txt_count,jump;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);

        btn_count = findViewById(R.id.btn_counter);
        btnReset = findViewById(R.id.btn_reset);
        txt_count = findViewById(R.id.txt_counter);
        jump = findViewById(R.id.txt_jump);
        btn_count.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int no,jmp;
                if (txt_count.getText().toString().isEmpty()){
                    txt_count.setText(String.valueOf(0));
                }
                if (jump.getText().toString().isEmpty() || Integer.parseInt(jump.getText().toString())<1){
                    jump.setText(String.valueOf(1));
                    jmp = 1;
                }
                jmp = Integer.parseInt(jump.getText().toString());
                no  = Integer.parseInt(txt_count.getText().toString());
                no+=jmp;
                txt_count.setText(String.valueOf(no));

            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_count.setText(String.valueOf(0));
                jump.setText(String.valueOf(1));
            }
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}