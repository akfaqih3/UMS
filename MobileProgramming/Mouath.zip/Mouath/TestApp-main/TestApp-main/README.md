# TestApp 
#This App is a small example for fetching data from Json API and async it to local SqlitDB
#Its a Challenge from Azora Company
