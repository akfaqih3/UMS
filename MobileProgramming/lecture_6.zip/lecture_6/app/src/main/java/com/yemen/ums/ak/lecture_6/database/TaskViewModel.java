package com.yemen.ums.ak.lecture_6.database;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

public class TaskViewModel extends ViewModel {

    private MutableLiveData<List<Task>> tasks = new MutableLiveData<>();
    private MutableLiveData<List<Task>> finishTasks = new MutableLiveData<>();

    public LiveData<List<Task>> getTasks(){
        return tasks;
    }

    public LiveData<List<Task>> getFinishTasks(){
        return finishTasks;
    }

    public void setTasks(List<Task> taskLists){
        tasks.setValue(taskLists);
    }

    public void setFinishTasksTasks(List<Task> taskLists){
        finishTasks.setValue(taskLists);
    }
}
