package com.yemen.ums.ak.lecture_6.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DataBaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "toDo" ;
    private static final int DATABASE_VERSION = 1 ;

    public DataBaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(Task.createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(Task.dropTable);
        onCreate(sqLiteDatabase);
    }

    public long insertRow(Task task){
        SQLiteDatabase db = getWritableDatabase() ;
        long insertLong = db.insert(Task.TABLE_NAME,
                null,
                task.getContentValues());
        db.close();
        return insertLong;
    }

    public Task getRow(int id){
        SQLiteDatabase db = getReadableDatabase();
        Task task = new Task();
        Cursor cursor = null;

        cursor = db.rawQuery(
                Task.selectById,
                new String[]{String.valueOf(id)}
        );

        if (cursor!=null){
            if (cursor.moveToFirst()){
                task.setId(id);
                task.setTitle(cursor.getString(1));
                task.setDescreption(cursor.getString(2));
                task.setStarted(Long.parseLong(cursor.getString(3)));
                task.setFinished(Long.parseLong(cursor.getString(4)));
            }
        }
        db.close();
        return task ;
    }

    public int getCount(){
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                Task.selectAllQuery,
                null
        );

        return cursor.getCount();
    }


    public List<Task> getAllTasks(){
        List<Task> tasks = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                Task.TABLE_NAME,
                Task.COLUMNS,
                null,null,null,null,Task.COLUMN_STARTED+" DESC "
        );

        if (cursor.moveToFirst()){
            do {
                tasks.add(new Task(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getLong(3),
                        cursor.getLong(4)
                ));

            }while (cursor.moveToNext());
        }
        db.close();
        return tasks;
    }

    public List<Task> getTasks(){
        List<Task> tasks = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                Task.TABLE_NAME,
                Task.COLUMNS,
                Task.COLUMN_FINISHED+" =? ",new String[]{"0"},null,null,Task.COLUMN_STARTED+" DESC "
        );

        if (cursor.moveToFirst()){
            do {
                tasks.add(new Task(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getLong(3),
                        cursor.getLong(4)
                ));

            }while (cursor.moveToNext());
        }
        db.close();
        return tasks;
    }

    public List<Task> getFinishedTask(){
        List<Task> tasks = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                Task.TABLE_NAME,
                Task.COLUMNS,
                Task.COLUMN_FINISHED+" >?",new String[]{"0"},null,null,Task.COLUMN_FINISHED+" DESC "
        );

        if (cursor.moveToFirst()){
            do {
                tasks.add(new Task(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getLong(3),
                        cursor.getLong(4)
                ));

            }while (cursor.moveToNext());
        }
        db.close();
        return tasks;
    }

    public void updateRow(Task task){
        Task taskUpadated ;
        SQLiteDatabase db = getWritableDatabase();

        db.update(
                Task.TABLE_NAME,
                task.getContentValues(),
                Task.whereCluaseId,
                new String[]{String.valueOf(task.getId())}
        );
        db.close();
    }

    public void finishTask(Task task){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Task.COLUMN_FINISHED,task.getFinished());
        db.update(
                Task.TABLE_NAME,
                contentValues,
                Task.whereCluaseId,
                new String[]{String.valueOf(task.getId())}
        );
        db.close();
    }
    public int deleteRow(int id){
        SQLiteDatabase db = getWritableDatabase();
        int deleteInt = db.delete(Task.TABLE_NAME,
                Task.whereCluaseId,
                new String[]{String.valueOf(id)});
        db.close();
        return deleteInt;
    }

}
