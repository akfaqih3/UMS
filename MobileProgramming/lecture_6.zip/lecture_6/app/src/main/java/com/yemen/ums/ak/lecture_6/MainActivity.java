package com.yemen.ums.ak.lecture_6;

import android.content.DialogInterface;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.widget.AlphabetIndexer;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.yemen.ums.ak.lecture_6.database.DataBaseHelper;
import com.yemen.ums.ak.lecture_6.database.Task;
import com.yemen.ums.ak.lecture_6.fragments.FragmentAdapter;
import com.yemen.ums.ak.lecture_6.fragments.doneFragment;
import com.yemen.ums.ak.lecture_6.fragments.tasksFragment;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    FragmentAdapter adapter ;
    Tag t;
    List<Fragment> fragmentList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TabLayout TabLayout = findViewById(R.id.tab_layout);
        ViewPager viewPager = findViewById(R.id.view_pager);

        fragmentList.add(new tasksFragment());
        fragmentList.add(new doneFragment());
        adapter = new FragmentAdapter(getSupportFragmentManager());

        adapter.addFragment(new tasksFragment(),"Tasks");
        adapter.addFragment(new doneFragment(),"Done");

        viewPager.setAdapter(adapter);

        TabLayout.setupWithViewPager(viewPager);

    }

    @Override
    protected void onStart() {
        super.onStart();

    }


}