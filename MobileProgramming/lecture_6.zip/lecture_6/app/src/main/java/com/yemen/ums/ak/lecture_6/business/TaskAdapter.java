package com.yemen.ums.ak.lecture_6.business;

import static androidx.core.content.ContextCompat.startActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;

import com.yemen.ums.ak.lecture_6.MainActivity;
import com.yemen.ums.ak.lecture_6.R;
import com.yemen.ums.ak.lecture_6.activities.AddTaskActivity;
import com.yemen.ums.ak.lecture_6.database.DataBaseHelper;
import com.yemen.ums.ak.lecture_6.database.Task;
import com.yemen.ums.ak.lecture_6.database.TaskViewModel;
import com.yemen.ums.ak.lecture_6.fragments.doneFragment;
import com.yemen.ums.ak.lecture_6.fragments.tasksFragment;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class TaskAdapter extends ArrayAdapter<Task> {

    private final List<Task> taskList ;
    private final Context context ;
    private final int resource ;

    public TaskAdapter(@NonNull Context context, int resource, List<Task> taskList) {
        super(context, resource, taskList);
        this.taskList = taskList;
        this.context = context;
        this.resource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        @SuppressLint("ViewHolder")
        View singleView = inflater.inflate(resource,parent,false);
        TextView txtTitle ,txtDescreption,txtStarted,txtFinished;
        CheckBox chkFinished ;
        CardView task_card ;

        txtTitle = singleView.findViewById(R.id.task_title);
        txtDescreption = singleView.findViewById(R.id.task_descreption);
        txtStarted = singleView.findViewById(R.id.task_started);
        txtFinished = singleView.findViewById(R.id.task_finished);
        chkFinished = singleView.findViewById(R.id.task_finished_chk);

        Task task = taskList.get(position);

        txtTitle.setText(task.getTitle());
        txtDescreption.setText(task.getDescreption());
        SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        txtStarted.setText(date.format(task.getStarted()));
        txtFinished.setText((task.getFinished()==0)?"0":date.format(task.getFinished()));
        chkFinished.setChecked((task.getFinished()==0)?false:true);

        chkFinished.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b){
                    task.setFinished(System.currentTimeMillis());

                }else {
                    task.setFinished(0);
                }
                DataBaseHelper dataBaseHelper = new DataBaseHelper(getContext());
                dataBaseHelper.finishTask(task);
                tasksFragment.taskViewModel.setTasks(dataBaseHelper.getTasks());
                doneFragment.taskViewModel.setFinishTasksTasks(dataBaseHelper.getFinishedTask());
            }
        });

        singleView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPopupActionBox( task);
            }
        });
        return singleView;
    }


    private void showPopupActionBox(Task task){
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle(task.getTitle());
        builder.setMessage(task.getDescreption());

        builder.setNegativeButton("edit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intentToEdit = new Intent(getContext(), AddTaskActivity.class);
                intentToEdit.putExtra("taskID",task.getId());
                startActivity(getContext(),intentToEdit,null);
            }
        });

        builder.setNeutralButton("delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                DataBaseHelper dataBaseHelper = new DataBaseHelper(getContext());
                dataBaseHelper.deleteRow(task.getId());
                tasksFragment.taskViewModel.setTasks(dataBaseHelper.getTasks());
                doneFragment.taskViewModel.setFinishTasksTasks(dataBaseHelper.getFinishedTask());
                Toast.makeText(getContext(),"Deleted"+task.getTitle(),Toast.LENGTH_LONG).show();
            }
        });
        builder.show();
    }
}
