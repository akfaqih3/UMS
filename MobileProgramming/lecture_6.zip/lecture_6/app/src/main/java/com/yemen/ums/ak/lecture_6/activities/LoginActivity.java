package com.yemen.ums.ak.lecture_6.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.yemen.ums.ak.lecture_6.MainActivity;
import com.yemen.ums.ak.lecture_6.R;

public class LoginActivity extends AppCompatActivity {
    String correctUsername = "akram";
    String correctPassword = "akram333";

    EditText username_txt ,password_txt;
    Button login_btn ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        username_txt = findViewById(R.id.usernameTXT);
        password_txt = findViewById(R.id.passwordTXT);
        login_btn = findViewById(R.id.loginBTN);
        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (username_txt.getText().toString().trim().isEmpty()){
                    username_txt.setError("must be not null");
                } else if (password_txt.getText().toString().trim().isEmpty()) {
                    password_txt.setError("must be not null");
                }else{
                    if (username_txt.getText().toString().trim().contentEquals(correctUsername) &&
                            password_txt.getText().toString().trim().equals(correctPassword)){

                        SharedPreferences sharedPreferences = getSharedPreferences("login_credentials", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();

                        editor.putString("username",username_txt.getText().toString().trim());
                        editor.putString("password",password_txt.getText().toString().trim());
                        editor.commit();

                        Intent toMain = new Intent(LoginActivity.this, MainActivity.class);
                        startActivity(toMain);
                        finish();
                    }
                }
            }
        });
    }
}