package com.yemen.ums.ak.lecture_6.database;

import android.content.ContentValues;

public class Task {

    public static final String TABLE_NAME = "Task";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_TITLE = "title" ;
    public static final String COLUMN_DESCREPTION = "descreption" ;
    public static final String COLUMN_PHOTO = "photo" ;
    public static final String COLUMN_STARTED = "started" ;
    public static final String COLUMN_FINISHED = "finished" ;

    public static final String[] COLUMNS = new String[]{COLUMN_ID,COLUMN_TITLE,COLUMN_DESCREPTION,COLUMN_STARTED,COLUMN_FINISHED};

    public static final String createTable = "CREATE TABLE IF NOT EXISTS "+TABLE_NAME+" ("
            +COLUMN_ID+" INTEGER PRIMARY KEY AUTOINCREMENT ,"
            +COLUMN_TITLE+" TEXT ,"
            +COLUMN_DESCREPTION+" TEXT ,"
            +COLUMN_STARTED+" TEXT ,"
            +COLUMN_FINISHED+" TEXT )" ;
    public static final String dropTable = "DROP TABLE IF EXISTS "+TABLE_NAME ;
    public static final String selectAllQuery = "SELECT * from "+TABLE_NAME ;
    public static final String selectById = "SELECT * FROM "+TABLE_NAME+" WHERE "+COLUMN_ID+" =?";
    public static final String whereCluaseId = COLUMN_ID+" =?";


    private  int id ;
    private String title ;
    private String descreption ;
    private byte[] photo ;
    private long started ;
    private long finished ;

    public Task() {

    }

    public Task(int id, String title, String descreption, long started, long finished) {
        this.id = id;
        this.title = title;
        this.descreption = descreption;
        this.started = started;
        this.finished = finished;
    }

    public Task(String title, String descreption, long started, long finished) {
        this.title = title;
        this.descreption = descreption;
        this.started = started;
        this.finished = finished;
    }

    public ContentValues getContentValues(){
        ContentValues contentValues = new ContentValues();

        contentValues.put(COLUMN_TITLE,this.getTitle());
        contentValues.put(COLUMN_DESCREPTION,this.getDescreption());
        contentValues.put(COLUMN_STARTED,this.getStarted());
        contentValues.put(COLUMN_FINISHED,this.getFinished());

        return contentValues ;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescreption() {
        return descreption;
    }

    public void setDescreption(String descreption) {
        this.descreption = descreption;
    }

    public long getStarted() {
        return started;
    }

    public void setStarted(long started) {
        this.started = started;
    }

    public long getFinished() {
        return finished;
    }

    public void setFinished(long finished) {
        this.finished = finished;
    }
}
