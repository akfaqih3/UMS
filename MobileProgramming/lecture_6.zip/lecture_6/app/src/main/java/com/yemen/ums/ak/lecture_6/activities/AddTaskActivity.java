package com.yemen.ums.ak.lecture_6.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.yemen.ums.ak.lecture_6.MainActivity;
import com.yemen.ums.ak.lecture_6.R;
import com.yemen.ums.ak.lecture_6.database.DataBaseHelper;
import com.yemen.ums.ak.lecture_6.database.Task;

import java.util.Calendar;

public class AddTaskActivity extends AppCompatActivity {
    EditText title ,descreption ;
    Button add ;
    CalendarView calendarView;
    ImageView imageView ;
    long date_started=0;
    Task task,taskToEdit=null;
    DataBaseHelper dataBaseHelper;
    Context context ;
    int taskIDtoEdit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_task);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        title = findViewById(R.id.title_txt);
        descreption = findViewById(R.id.descreption_txt);
        calendarView = findViewById(R.id.date_picker_actions);
        imageView = findViewById(R.id.action_image);
        add = findViewById(R.id.addTask_btn);
        context = getApplicationContext();

        Intent intent = getIntent() ;
        taskIDtoEdit = intent.getIntExtra("taskID",-1);
        if (taskIDtoEdit !=-1){
            dataBaseHelper = new DataBaseHelper(context);
            taskToEdit = dataBaseHelper.getRow(taskIDtoEdit);
            title.setText(taskToEdit.getTitle());
            descreption.setText(taskToEdit.getDescreption());
            calendarView.setDate(taskToEdit.getStarted());
            add.setText("Edit");
        }

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int i, int i1, int i2) {
                Calendar calendar  = Calendar.getInstance();
                calendar.set(i,i1,i2);
                date_started = calendar.getTimeInMillis();
            }
        });
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (title.getText().toString().trim().isEmpty() || descreption.getText().toString().trim().isEmpty()){
                    Toast.makeText(getApplicationContext(),"please all field",Toast.LENGTH_LONG).show();
                }
                else{
                    task = new Task(title.getText().toString().trim(),
                            descreption.getText().toString().trim(),
                            (date_started==0)?System.currentTimeMillis():date_started,
                            0);

                    dataBaseHelper = new DataBaseHelper(context);
                    if (taskIDtoEdit == -1){
                        dataBaseHelper.insertRow(task);
                    }else{
                        task.setId(taskIDtoEdit);
                        task.setStarted((date_started==0)?taskToEdit.getStarted():date_started);
                        task.setFinished(taskToEdit.getFinished());
                        dataBaseHelper.updateRow(task);
                    }

                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    finish();
                }

            }
        });

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

    }
}