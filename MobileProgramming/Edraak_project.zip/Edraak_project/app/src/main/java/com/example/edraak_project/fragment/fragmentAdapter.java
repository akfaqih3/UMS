package com.example.edraak_project.fragment;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import java.util.ArrayList;
import java.util.List;

public class fragmentAdapter extends FragmentStatePagerAdapter{
    private final  List<Fragment> fragmentList = new ArrayList<>();
    private final  List<String> fragmentListTitle = new ArrayList<>();

    public fragmentAdapter(@NonNull FragmentManager fm) {
        super(fm);

    }
    public void addFragment(Fragment fragment,String title){
        fragmentList.add(fragment);
        fragmentListTitle.add(title);
    }


    @NonNull
    @Override
    public Fragment getItem(int position) {
        return fragmentList.get(position);
    }

    @Override
    public int getCount() {
        return fragmentList.size();
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return fragmentListTitle.get(position);
    }
}