package com.example.edraak_project;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;

import java.util.Map;

public class SplashActivity extends Activity implements View.OnClickListener {
    RelativeLayout splash;
    SharedPreferences preferences ;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_layout);
        splash = findViewById(R.id.splashLR);
        splash.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        preferences = getSharedPreferences("login",Context.MODE_PRIVATE);
        String savedEmail = preferences.getString("login_email","");
        if (!savedEmail.isEmpty()) {
            Intent toMain = new Intent(SplashActivity.this,MainActivity.class);
            startActivity(toMain);
            finish();
        }else{
            Intent toLogin = new Intent(SplashActivity.this, LoginActivity.class);
            startActivity(toLogin);
            finishActivity(SplashActivity.this.getClass().getModifiers());
        }
    }

}
