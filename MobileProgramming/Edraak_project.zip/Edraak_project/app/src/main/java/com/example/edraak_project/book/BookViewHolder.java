package com.example.edraak_project.book;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.edraak_project.R;

public class BookViewHolder extends RecyclerView.ViewHolder {
    TextView title,author,date;
    public BookViewHolder(@NonNull View itemView) {
        super(itemView);
        title = itemView.findViewById(R.id.title_txt);
        author = itemView.findViewById(R.id.author_txt);
        date = itemView.findViewById(R.id.date_txt);
    }
}
