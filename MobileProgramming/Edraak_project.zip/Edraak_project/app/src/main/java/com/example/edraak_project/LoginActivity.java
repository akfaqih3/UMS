package com.example.edraak_project;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.PatternMatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.collection.ArraySet;

import java.math.MathContext;

public class LoginActivity extends Activity implements View.OnClickListener {
    String correctEmail="akram@gmail.com";
    String correctPasswod="akram333";
    EditText email,password;
    Spinner type;
    Button login;

    String[] user_type={"User","Store","Admin"};
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);
        email = findViewById(R.id.email_ET);
        password=findViewById(R.id.password_ET);
        login =findViewById(R.id.login_btn);
        login.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        if (email.getText().toString().isEmpty()){
            email.setError("must be not null");
        }
        else if(password.getText().toString().isEmpty()){
            password.setError("must be not null");
        }else{

            if (email.getText().toString().trim().equalsIgnoreCase(correctEmail) && password.getText().toString().trim().equals(correctPasswod)){
                Toast.makeText(getApplicationContext(), "Succesfully login.", Toast.LENGTH_SHORT).show();

                SharedPreferences sharedPreferences = getSharedPreferences("login",Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("login_email",email.getText().toString().trim());
                editor.putString("login_password",password.getText().toString().trim());
                editor.commit();

                Intent toMainActivity = new Intent(this,MainActivity.class);
                toMainActivity.putExtra("email_user",email.getText().toString());
                startActivity(toMainActivity);

            }else{
                Toast.makeText(this, "email or password incorrect.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
