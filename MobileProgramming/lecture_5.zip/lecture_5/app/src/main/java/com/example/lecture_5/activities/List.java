package com.example.lecture_5.activities;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lecture_5.R;
import com.example.lecture_5.database.DataBaseHelper;
import com.example.lecture_5.models.ToDoModel;

import java.util.ArrayList;
import java.util.jar.Attributes;

public class List extends AppCompatActivity {
    public TextView title,descreption,started,finished;
    ArrayList<ToDoModel> todo ;
    RelativeLayout list ;
    LinearLayout card ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_list);

        list = findViewById(R.id.list_rl);
        card = findViewById(R.id.todo_card);
        title = findViewById(R.id.title);
        descreption = findViewById(R.id.descreption);
        started = findViewById(R.id.started);
        finished = findViewById(R.id.finished);


        DataBaseHelper db = new DataBaseHelper(this);
        todo = db.getAllToDo();
        int no = todo.size() -1 ;
        title.setText(todo.get(no).getTitle().toString());
        descreption.setText(todo.get(no).getDescreption().toString());
        started.setText(String.valueOf(todo.get(no).getStarted()));
        finished.setText(String.valueOf(todo.get(no).getFinished()));

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.title), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

       
    }

}