package com.example.lecture_5.models;

public class ToDoModel {
    private int id ;
    private  String title ;
    private  String descreption ;
    private  long started ;
    private  long finished ;

    public ToDoModel() {

    }

    public ToDoModel(int id, String title, String descreption, long started, long finished) {
        this.id = id;
        this.title = title;
        this.descreption = descreption;
        this.started = started;
        this.finished = finished;
    }

    public ToDoModel(String title, String descreption, long started, long finished) {
        this.title = title;
        this.descreption = descreption;
        this.started = started;
        this.finished = finished;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescreption() {
        return descreption;
    }

    public long getStarted() {
        return started;
    }

    public long getFinished() {
        return finished;
    }
}
