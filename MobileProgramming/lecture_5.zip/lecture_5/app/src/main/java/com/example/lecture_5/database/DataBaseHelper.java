package com.example.lecture_5.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.lecture_5.MainActivity;
import com.example.lecture_5.models.ToDoModel;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class DataBaseHelper extends SQLiteOpenHelper {

    static String DATABASE_NAME = "db_todo";
    static int DATABASE_VERSION = 1 ;
    static  String TABLE_TODO = "tb_todo" ;
    static  String ID_TODO = "id" ;
    static  String TITLE_TODO = "title";
    static  String DESCREPTION_TODO = "descreption" ;
    static  String STARTED_TODO = "started" ;
    static  String FINISHED_TODO = "finished" ;

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String createTodoTableQuery = "CREATE TABLE IF NOT EXISTS "+TABLE_TODO+" (" +
                ""+ID_TODO+" INTEGER PRIMARY KEY AUTOINCREMENT, "
                +TITLE_TODO+" TEXT,"
                +DESCREPTION_TODO+" TEXT,"
                +STARTED_TODO+" TEXT,"
                +FINISHED_TODO+" TEXT)";

        sqLiteDatabase.execSQL(createTodoTableQuery);
        sqLiteDatabase.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String dropTodoTableQuery = "DROP TABLE IF EXISTS "+TABLE_TODO+" ;";

        sqLiteDatabase.execSQL(dropTodoTableQuery);

        onCreate(sqLiteDatabase);
    }

    public DataBaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.onCreate(this.getWritableDatabase());
    }

    public String insertToDoQuery(ToDoModel todo){
        String query = "INSERT INTO "+TABLE_TODO+"("
                +TITLE_TODO+","+DESCREPTION_TODO+","+STARTED_TODO+","+FINISHED_TODO+") values("
                +todo.getTitle()+","+todo.getDescreption()+","+todo.getStarted()+","+todo.getFinished()+") ";

        return  query ;
    }

    public  String selectAllQuery(){
        String query = "select * from "+TABLE_TODO+" ;";
        return  query ;
    }

    public void createTodo(ToDoModel _ToDoModel){
        SQLiteDatabase sql = getWritableDatabase();
        ContentValues row = new ContentValues();

        row.put("title",_ToDoModel.getTitle());
        row.put("descreption",_ToDoModel.getDescreption());
        row.put("started",_ToDoModel.getStarted());
        row.put("finished",_ToDoModel.getFinished());
        sql.insert(
                TABLE_TODO,
                null,
                row

        );
        sql.close();
    }

    public ArrayList<ToDoModel> getAllToDo(){
        ArrayList allTodDo = new ArrayList<ToDoModel>();
        SQLiteDatabase sql = getReadableDatabase();
        String[] clm = {ID_TODO,TITLE_TODO,DESCREPTION_TODO,STARTED_TODO,FINISHED_TODO};
        Cursor allRow ;
        allRow = sql.query(TABLE_TODO,clm,null,null,null,null,null);

        if (allRow.moveToFirst()){
            do {
                ToDoModel curr = new ToDoModel(
                        allRow.getInt(0),
                        allRow.getString(1),
                        allRow.getString(2),
                        allRow.getLong(3),
                        allRow.getLong(4)
                );
                allTodDo.add(curr);
            }while (allRow.moveToNext());
        }
        return  allTodDo ;
    }
}
