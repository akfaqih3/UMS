package com.example.lecture_5.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.lecture_5.R;
import com.example.lecture_5.database.DataBaseHelper;
import com.example.lecture_5.models.ToDoModel;

public class Add extends Activity implements View.OnClickListener {
    EditText title , descreption;
    Button add ,list;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        title = findViewById(R.id.title_txt);
        descreption = findViewById(R.id.descreption_txt);
        add = findViewById(R.id.add_btn);
        list = findViewById(R.id.toList_btn);

        add.setOnClickListener(this);
        list.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.toList_btn){
            Intent toList = new Intent(Add.this,List.class);
            startActivity(toList);
        }


        if (view.getId() == R.id.add_btn){
            ToDoModel ToDo = new ToDoModel(
                    title.getText().toString().trim(),
                    descreption.getText().toString().trim(),
                    System.currentTimeMillis(),
                    0
            );

            DataBaseHelper db = new DataBaseHelper(this);
            db.createTodo(ToDo);
        }
    }
}
