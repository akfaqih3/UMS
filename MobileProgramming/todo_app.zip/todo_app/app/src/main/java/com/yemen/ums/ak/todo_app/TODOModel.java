package com.yemen.ums.ak.todo_app;

import android.graphics.Bitmap;

public class TODOModel {

    private int id;
    private String title;
    private String description;
    private long started;
    private long finished;
    private Bitmap image ;

    public TODOModel() {

    }

    public TODOModel(String title, String description, long started, long finished, Bitmap image) {
        this.title = title;
        this.description = description;
        this.started = started;
        this.finished = finished;
        this.image = image;
    }

    public TODOModel(int id, String title, String description, long started, long finished, Bitmap image) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.started = started;
        this.finished = finished;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getStarted() {
        return started;
    }

    public void setStarted(long started) {
        this.started = started;
    }

    public long getFinished() {
        return finished;
    }

    public void setFinished(long finished) {
        this.finished = finished;
    }

    public Bitmap getImage() {
        return image;
    }

    public void setImage(Bitmap image) {
        this.image = image;
    }
}
