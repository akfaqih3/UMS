package com.yemen.ums.ak.todo_app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
public class ActivityAddTODO extends AppCompatActivity {

    TextView txtBanner;

    EditText etTitle, etDescription;
    Button btnAddTODO,btnuploadTODO;
    Context context;
    DBHandler dbHandler;
    private ImageView objectImageView;
    private static final int PICK_IMAGE_REQUEST =100;
    private Uri imageFilePath;
    private Bitmap imageToStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_todo);

        txtBanner = findViewById(R.id.txtBanner);
        etTitle = findViewById(R.id.title);
        etDescription = findViewById(R.id.description);
        btnAddTODO = findViewById(R.id.btnAddToDo);
        btnuploadTODO = findViewById(R.id.btnUploadToDo);
        context = getApplicationContext();
        dbHandler = new DBHandler(context);
        objectImageView = findViewById(R.id.image);
        // Add new ToDo action button
        btnuploadTODO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent objectIntent;
                    objectIntent = new Intent();
                    objectIntent.setType("image/*");
                    objectIntent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(objectIntent,PICK_IMAGE_REQUEST);
                }
                catch (Exception e)
                {
                    Toast.makeText(ActivityAddTODO.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                }

            }
        });
        btnAddTODO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title, description;
                long started, finished;
                // get user input data
                title = etTitle.getText().toString().trim();
                description = etDescription.getText().toString().trim();
                started = System.currentTimeMillis();
                finished = 0;

                if(!title.isEmpty()) {

                    // set user input all data to todo model class
                    TODOModel todoModel = new TODOModel(title, description, started, finished,imageToStore);

                    // parse todo model data to it
                    dbHandler.insertData(todoModel);

                    // back to the activity main
                    startActivity(new Intent(context, MainActivity.class));
                    Toast.makeText(context, "تم اضافة مهمد جديدة بنجاح.", Toast.LENGTH_LONG).show();
                } else
                    Toast.makeText(context, "العنوان فارغ!", Toast.LENGTH_SHORT).show();

            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        try {
            super.onActivityResult(requestCode, resultCode,data);
            if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null){
                imageFilePath = data.getData();
                imageToStore = MediaStore.Images.Media.getBitmap(getContentResolver(),imageFilePath);

                objectImageView.setImageBitmap(imageToStore);
            }
        }
        catch (Exception e)
        {
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
        }

    }

}