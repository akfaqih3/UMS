package com.yemen.ums.ak.todo_app;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import androidx.annotation.Nullable;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class DBHandler extends SQLiteOpenHelper {

    public static final String DB_NAME = "todo";
    public static final int VERSION = 1;
    public static final String TABLE_NAME = "todo";
    public static final String ID = "id";
    public static final String TITLE = "title";
    public static final String DESCRIPTION = "description";
    public static final String STARTED = "started";
    public static final String FINISHED = "finished";
    public static final String IMAGE = "image";
    private ByteArrayOutputStream objectByteArrayOutputStream;
    private byte[] imageInBytes;
    public DBHandler(@Nullable Context context) {
        super(context, DB_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        /*
         *  CREATE TABLE todo
         *      ( id INTEGER PRIMARY KEY AUTOINCREMENT
         *      , title TEXT
         *      , description TEXT
         *      , started TEXT
         *      , finished TEXT );
         */
        final String TABLE_CREATE_QUERY = "CREATE TABLE " + TABLE_NAME
                + "("
                + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + TITLE + " TEXT, "
                + DESCRIPTION + " TEXT, "
                + STARTED + " TEXT, "
                + FINISHED + " TEXT,"
                + IMAGE + " BLOB"
                + ");";

        // execute SQL query
        db.execSQL(TABLE_CREATE_QUERY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // drop table if database version has benn updated
        String TABLE_DROP_QUERY = "DROP TABLE IF EXISTS " + TABLE_NAME;
        // execute SQL query
        db.execSQL(TABLE_DROP_QUERY);
        // crete again new database
        onCreate(db);
    }

    // add new todo to the todo table
    public void insertData(TODOModel todoModel) {

        // get writable access from database
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        if(todoModel.getImage()!=null){
            Bitmap imageToStoreBitmap = todoModel.getImage();

            objectByteArrayOutputStream = new ByteArrayOutputStream();
            imageToStoreBitmap.compress(Bitmap.CompressFormat.JPEG,100, objectByteArrayOutputStream);

            imageInBytes = objectByteArrayOutputStream.toByteArray();
        }
        // struct user data data inside of content values object
        ContentValues todoContentValues = new ContentValues();
        todoContentValues.put(TITLE, todoModel.getTitle());
        todoContentValues.put(DESCRIPTION, todoModel.getDescription());
        todoContentValues.put(STARTED, todoModel.getStarted());
        todoContentValues.put(FINISHED, todoModel.getFinished());
        todoContentValues.put(IMAGE,imageInBytes);

        // insert data to the table
        sqLiteDatabase.insert(TABLE_NAME, null, todoContentValues);
        //close database  connection
        sqLiteDatabase.close();
    }

    // get todos count
    public int getTODOCount() {

        // get readable access from the database
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        // define select all query from the database
        final String SELECT_ALL_QUERY = "SELECT * FROM " + TABLE_NAME;
        // execute sql query
        @SuppressLint("Recycle")
        Cursor allTODOCursor = sqLiteDatabase.rawQuery(SELECT_ALL_QUERY, null);
        // get count
        return allTODOCursor.getCount();
    }

    // get all todo from the todo table
    public List<TODOModel> getAllTODOS() throws Exception {

        // define empty todos array list and database readable object
        ArrayList<TODOModel> todos = new ArrayList<>();
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();

        try {


            // define sqlite select query and execute it
            Cursor allTODOCursor = sqLiteDatabase.query(
                    TABLE_NAME
                    , new String[]{ID, TITLE, DESCRIPTION, STARTED, FINISHED,IMAGE}
                    , null, null, null, null
                    , ID + " DESC");

            // get first row and check if it's null table or not
            if (allTODOCursor.moveToFirst()) {
                // if it is not null so, get cursor object have data column by column and parse it in to the model class
                do {
                    TODOModel todoModel = new TODOModel();
                    todoModel.setId( allTODOCursor.getInt(0));
                    todoModel.setTitle( allTODOCursor.getString(1));
                    todoModel.setDescription( allTODOCursor.getString(2));
                    todoModel.setStarted( allTODOCursor.getLong(3));
                    todoModel.setFinished( allTODOCursor.getLong(4));
                    if(allTODOCursor.getBlob(5)!=null) {
                        byte[] imageBytes = allTODOCursor.getBlob(5);

                        Bitmap objectBitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
                        todoModel.setImage(objectBitmap);
                    }

                    // add model object in to the array list
                    todos.add(todoModel);
                } while (allTODOCursor.moveToNext());
            }

            // return all todo array list
            return todos;
        }catch (Exception e){
            throw  new Exception(e.getMessage().toString());
        }
    }

    // delete single todo
    public void deleteSingleTodo(int id) {

        // get writable access from the database
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        // delete row is equal to the id
        sqLiteDatabase.delete(TABLE_NAME, ID + " = ?", new String[]{String.valueOf(id)});
        sqLiteDatabase.close();
    }

    // select single todo by id
    public TODOModel selectSingleTodo(int id) {

        // get reference to the database, write select query and execute
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        @SuppressLint("Recycle")
        Cursor selectedTodo = sqLiteDatabase.query(
                TABLE_NAME
                , new String[]{ID, TITLE, DESCRIPTION, STARTED, FINISHED,IMAGE}
                , ID + " = ? "
                , new String[]{String.valueOf(id)}
                , null, null, null);

        // set selected row to the model class and return if it isn't null
        TODOModel todo;
        if (selectedTodo.moveToFirst()) {
            todo= new TODOModel();
            todo.setId( selectedTodo.getInt(0));
            todo.setTitle( selectedTodo.getString(1));
            todo.setDescription( selectedTodo.getString(2));
            todo.setStarted( selectedTodo.getLong(3));
            todo.setFinished( selectedTodo.getLong(4));
            if(selectedTodo.getBlob(5)!=null) {
                byte[] imageBytes = selectedTodo.getBlob(5);
                Bitmap objectBitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
                todo.setImage(objectBitmap);
            }

            // add model object in to the array list
            return todo;
        }

        return null;
    }

    // update single todo
    public int updateSingleTodo(TODOModel todoModel) {

        // get reference to the database
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();

        // set data into the content values object
        ContentValues contentValues = new ContentValues();
        contentValues.put(TITLE, todoModel.getTitle());
        contentValues.put(DESCRIPTION, todoModel.getDescription());
        contentValues.put(STARTED, todoModel.getStarted());
        contentValues.put(FINISHED, todoModel.getFinished());
        contentValues.put(FINISHED, todoModel.getFinished());

        // update row
        return sqLiteDatabase.update(
                TABLE_NAME
                , contentValues
                , ID + " = ? "
                , new String[]{String.valueOf(todoModel.getId())});
    }

    // finish todo
    public int finishTodo(TODOModel todoModel) {

        // get reference to the database
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        // set data into the content values object
        ContentValues contentValues = new ContentValues();
        contentValues.put(FINISHED, todoModel.getFinished());

        return sqLiteDatabase.update(
                TABLE_NAME
                , contentValues
                , ID + " = ? "
                , new String[]{String.valueOf(todoModel.getId())});
    }
}